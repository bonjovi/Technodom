<?php

if (!defined('SHORTCODE_REGISTER_CONTENT_IN_ADMIN')) {
    define('SHORTCODE_REGISTER_CONTENT_IN_ADMIN', 'sc-content-admin');
}
