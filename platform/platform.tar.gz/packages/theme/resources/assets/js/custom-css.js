$(document).ready(() => {
    Botble.initCodeEditor('custom_css');
});