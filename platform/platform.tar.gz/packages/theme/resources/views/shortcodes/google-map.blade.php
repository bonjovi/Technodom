<div style="height: 400px; width: 100%; position: relative; text-align: right;">
    <div  style="height: 400px; width: 100%; overflow: hidden; background: none!important;">
        <iframe width="100%" height="500" src="https://maps.google.com/maps?q={{ addslashes($address) }}%20&t=&z=13&ie=UTF8&iwloc=&output=embed"
                frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
    </div>
</div>
