<?php

namespace Botble\Theme\Exceptions;

use UnexpectedValueException;

class UnknownViewFileException extends UnexpectedValueException
{
}
