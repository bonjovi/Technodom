<?php

namespace Botble\Theme\Contracts;

interface Theme
{
}
