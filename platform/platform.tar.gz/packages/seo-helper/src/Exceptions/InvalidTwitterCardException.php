<?php

namespace Botble\SeoHelper\Exceptions;

class InvalidTwitterCardException extends InvalidArgumentException
{
}
