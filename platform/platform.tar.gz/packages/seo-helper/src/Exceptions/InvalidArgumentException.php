<?php

namespace Botble\SeoHelper\Exceptions;

class InvalidArgumentException extends SeoHelperException
{
}
