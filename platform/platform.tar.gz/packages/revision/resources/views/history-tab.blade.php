<li class="nav-item">
    <a href="#tab_history" class="nav-link" data-toggle="tab">{{ trans('core/base::tabs.revision') }} </a>
</li>